﻿using MySql.Data;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 
namespace DataLP
{
    public class MySQL
    {

        #region CONSTRUCTOR/DEFAULT ACCOUNT MANAGEMENT
        /*
         * 
         * Connection to the database is created, and a select is run to check whether or not the default account already exists.
         * If the default account doesn't already exist, one will be created and inserted into the accounts table in the project's MySQL database.
         * 
         */

        //
        // Constructor
        //
        public MySQL()
        { 
            //
            // Initial database connection string created
            //
            string connectionString = "SERVER=localhost;DATABASE=swendiverfinalproject;UID=root;PASSWORD=Snowboard1!;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            //
            // Select command created with the connection to project's database
            //
            MySqlCommand checkDefault = new MySqlCommand("SELECT * FROM Accounts WHERE playerUsername = 'Default' AND playerPassword = 'password'", connection);
            //
            // Connection is opened, and select is run.
            //
            connection.Open();

            MySqlDataReader MySelectReader;

            MySelectReader = checkDefault.ExecuteReader();
            //
            // Checking if the default account is found in any rows within the accounts database
            //
            bool hasRows = false;
            while (MySelectReader.Read())
            {
                if (MySelectReader.HasRows)
                {
                    //
                    //If default account already exists, don't create another one.
                    //
                    hasRows = true;
                    break;
                }
            }
            connection.Close();
            //
            // Running the check, if a row has been found it will disregard, if one isn't found then a default account is created
            //
            if (hasRows)
            {
                //
                // Disregarding the creation as an account has been found
                //
                CurrentUsername = "Default";
                CurrentPassword = "password";
            }
            else if (!hasRows)
            {
                //
                // Create the new Default Account
                //

                //
                // Insert command is created and sent to the database with the connection string ( ACCOUNT IS CREATED HERE ) 
                //
                MySqlCommand cmd = new MySqlCommand("INSERT INTO Accounts(playerUsername, playerPassword) VALUES('Default', 'password')",connection);
                connection.Open();
                MySqlDataReader MyReader;
                MyReader = cmd.ExecuteReader();
                while (MyReader.Read()){}
                CurrentUsername = "Default";
                CurrentPassword = "password";
            } 
            connection.Close();
        }
        #endregion

        #region AccountManagement

        #region FIELDS
        private string username;
        private string currentUsername;
        private string password;
        private string currentPassword;
        #endregion

        #region PROPERTIES


        public string CurrentUsername
        {
            get { return currentUsername; }
            set { currentUsername = value; }
        }

        public string CurrentPassword
        {
            get { return currentPassword; }
            set { currentPassword = value; }
        }
         
        public string Username
        {
            get { return username; }
            set { username = value; }
        }


        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        #region Properties

        private int gold;

        public int Gold
        {
            get { return gold; }
            set { gold = value; }
        }

        private int playerX;

        public int PlayerX
        {
            get { return playerX; }
            set { playerX = value; }
        }

        private int playerY;

        public int PlayerY
        {
            get { return playerY; }
            set { playerY = value; }
        }

        private string weapon;

        public string Weapon
        {
            get { return weapon; }
            set { weapon = value; }
        }

        private double health;

        public double Health
        {
            get { return health; }
            set { health = value; }
        }

        private double shield;

        public double Shield
        {
            get { return shield; }
            set { shield = value; }
        }

        private string playerClass;

        public string PlayerClass
        {
            get { return playerClass; }
            set { playerClass = value; }
        }
        private int level;

        public int Level
        {
            get { return level; }
            set { level = value; }
        }

        private double playerXP;

        public double PlayerXP
        {
            get { return playerXP; }
            set { playerXP = value; }
        }

        private bool isAlive;

        public bool IsAlive
        {
            get { return isAlive; }
            set { isAlive = value; }
        }

        private double playerShieldMax;

        public double ShieldMax 
        {
            get { return playerShieldMax; }
            set { playerShieldMax = value; }
        }

        private double healthMax;

        public double HealthMax
        {
            get { return healthMax; }
            set { healthMax = value; }
        }
        private double basicAttack;

        public double BasicAttack
        {
            get { return basicAttack; }
            set { basicAttack = value; }
        }
        private int storyPart;

        public int StoryPart
        {
            get { return storyPart; }
            set { storyPart = value; }
        }

        private int storySection;

        public int StorySection 
        {
            get { return storySection; }
            set { storySection = value; }
        }

        private string storyDialogue;

        public string Dialogue
        {
            get { return storyDialogue; }
            set { storyDialogue = value; }
        }


        #endregion

        #region Methods

        public bool CreateAccount()
        {
            if (Username != "" && Password != "" && Username != "Default")
            {


            //
            // Initial database connection string created
            //
            string connectionString = "SERVER=localhost;DATABASE=swendiverfinalproject;UID=root;PASSWORD=Snowboard1!;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            //
            // Select command created with the connection to project's database
            // 
            MySqlCommand checkDefault = new MySqlCommand("SELECT * FROM Accounts WHERE playerUsername = '"+Username+"'", connection);
            //
            // Connection is opened, and select is run.
            //
            connection.Open();

            MySqlDataReader MySelectReader;

            MySelectReader = checkDefault.ExecuteReader();
            //
            // Checking if the default account is found in any rows within the accounts database
            //
            bool hasRows = false;
            while (MySelectReader.Read())
            {
                if (MySelectReader.HasRows)
                {
                        //
                        //If default account already exists, don't create another one.
                        //
                    hasRows = true;
                    break;
                }
            }
            connection.Close();
            //
            // Running the check, if a row has been found it will disregard, if one isn't found then a default account is created
            //
            if (hasRows)
            {
                //
                // !!!Provide Feedback to user if account already exists!!!
                //



                return true;

            }
            else if (!hasRows)
            {
                
                //
                // Insert command is created and sent to the database with the connection string ( ACCOUNT IS CREATED HERE ) 
                //
                
                MySqlCommand cmd = new MySqlCommand("INSERT INTO Accounts(playerUsername, playerPassword) VALUES('"+Username+"', '"+Password+"')", connection);
                connection.Open();
                MySqlDataReader MyReader;
                MyReader = cmd.ExecuteReader();
                    CurrentUsername = Username;
                    CurrentPassword = Password;
                while (MyReader.Read()) { }

            }
            connection.Close();
            return false;
            }
            return false;
        }

        public void ReadAccount()
        {

        }

        public bool SaveAccount()
        {

            if (CurrentUsername != "")
            { 
                //
                // Initial database connection string created
                //
                string connectionString = "SERVER=localhost;DATABASE=swendiverfinalproject;UID=root;PASSWORD=Snowboard1!;";
                MySqlConnection connection = new MySqlConnection(connectionString);
                //
                // Select command created with the connection to project's database
                // 
                MySqlCommand checkDefault = new MySqlCommand("SELECT * FROM userproperties WHERE playerUsername = '" + CurrentUsername + "'", connection);
                //
                // Connection is opened, and select is run.
                //
                connection.Open();

                MySqlDataReader MySelectReader;

                MySelectReader = checkDefault.ExecuteReader();
                //
                // Checking if the default account is found in any rows within the accounts database
                //
                bool hasRows = false;
                while (MySelectReader.Read())
                {
                    if (MySelectReader.HasRows)
                    {
                        //
                        //If default account already exists, don't create another one.
                        //







                        hasRows = true;
                        break;
                    }
                }
                connection.Close();
                //
                // Running the check, if a row has been found it will disregard, if one isn't found then a default account is created
                //
                if (hasRows)
                {
                    //
                    // !!!Provide Feedback to user if account already exists!!!
                    //


                    MySqlCommand cmd = new MySqlCommand("DELETE FROM userproperties WHERE playerUsername = '" + CurrentUsername + "'", connection);
                    connection.Open();
                    MySqlDataReader MyReader;
                    MyReader = cmd.ExecuteReader();
                    while (MyReader.Read()) { }
                    connection.Close();

                    
                    /*
                    MySqlCommand cmd2 = new MySqlCommand("INSERT INTO userproperties(playerUsername, gold, playerX, playerY, weapon, health, shield, class, playerLevel, playerXP, isAlive, playerShieldMax, playerHealthMax, basicAttack, storyPart, storySelection, storyDialogue) VALUES('"+CurrentUsername+ "', '"+Gold+"', '"+PlayerX+"', '"+PlayerY+"', '"+Weapon+"', '"+Health+"', '"+Shield+"', '"+PlayerClass+"', '"+Level+"', '"+PlayerXP+ "', '"+IsAlive+"','"+playerShieldMax+"','"+HealthMax+"','"+BasicAttack+ "','"+StoryPart+ "', '"+StorySection+"','"+Dialogue+"'", connection);
                    connection.Open();
                    MySqlDataReader MyReader2;
                    MyReader = cmd.ExecuteReader();
                    while (MyReader.Read()) { }
                    connection.Close();
                    */

                    return true;

                }
                else if (!hasRows)
                {

                    //
                    // UPDATE command is created and sent to the database with the connection string ( ACCOUNT IS UPDATED HERE ) 
                    //

                    


                }
                connection.Close();
                return false;
            }
            return false;


        }

        public bool UpdateAccount(string newName)
        {
            if (Username != "" && Password != "" && newName!="")
            {


                //
                // Initial database connection string created
                //
                string connectionString = "SERVER=localhost;DATABASE=swendiverfinalproject;UID=root;PASSWORD=Snowboard1!;";
                MySqlConnection connection = new MySqlConnection(connectionString);
                //
                // Select command created with the connection to project's database
                // 
                MySqlCommand checkDefault = new MySqlCommand("SELECT * FROM Accounts WHERE playerUsername = '" + newName + "'", connection);
                //
                // Connection is opened, and select is run.
                //
                connection.Open();

                MySqlDataReader MySelectReader;

                MySelectReader = checkDefault.ExecuteReader();
                //
                // Checking if the default account is found in any rows within the accounts database
                //
                bool hasRows = false;
                while (MySelectReader.Read())
                {
                    if (MySelectReader.HasRows)
                    {
                        //
                        //If default account already exists, don't create another one.
                        //
                        hasRows = true;
                        break;
                    }
                }
                connection.Close();
                //
                // Running the check, if a row has been found it will disregard, if one isn't found then a default account is created
                //
                if (hasRows)
                {
                    //
                    // !!!Provide Feedback to user if account already exists!!!
                    //



                    return true;

                }
                else if (!hasRows)
                { 

                    //
                    // UPDATE command is created and sent to the database with the connection string ( ACCOUNT IS UPDATED HERE ) 
                    //

                    MySqlCommand cmd = new MySqlCommand("UPDATE Accounts SET playerUsername = '"+ newName +"' WHERE playerUsername = '"+CurrentUsername+"'", connection);
                    connection.Open();
                    MySqlDataReader MyReader;
                    MyReader = cmd.ExecuteReader();
                    while (MyReader.Read()) { }
                    CurrentUsername = newName;
                    Username = newName;


                }
                connection.Close();
                return false;
            }
            return false;
        }


        public void DeleteAccount(string name)
        {

            /*
             * DELETING ACCOUNT FROM THE ACCOUNTS TABLE WORKS, LATER ON IN THE PROJECT ADD IN THE ABILITY
             * TO DELETE EVERYTHING ELSE RELATED TO THAT PLAYER'S PROFILE IN THE OTHER TABLES.
             */



            if (name != "" && name != "Default")
            {


                //
                // Initial database connection string created
                //
                string connectionString = "SERVER=localhost;DATABASE=swendiverfinalproject;UID=root;PASSWORD=Snowboard1!;";
                MySqlConnection connection = new MySqlConnection(connectionString);
                //
                // Select command created with the connection to project's database
                // 
                MySqlCommand checkDefault = new MySqlCommand("SELECT * FROM Accounts WHERE playerUsername = '" + name + "'", connection);
                //
                // Connection is opened, and select is run.
                //
                connection.Open();

                MySqlDataReader MySelectReader;

                MySelectReader = checkDefault.ExecuteReader();
                //
                // Checking if the default account is found in any rows within the accounts database
                //
                bool hasRows = false;
                while (MySelectReader.Read())
                {
                    if (MySelectReader.HasRows)
                    {
                        //
                        //If default account already exists
                        //
                        hasRows = true;
                        break;
                    }
                }
                connection.Close();
                //
                // Running the check, if a row has been found it will disregard, if one isn't found then a default account is created
                //
                if (hasRows)
                {
                    //
                    // Delete command is created and sent to the database with the connection string ( ACCOUNT IS DELETE HERE ) 
                    //
                    MySqlCommand cmd = new MySqlCommand("DELETE FROM Accounts WHERE playerUsername = '" + name + "'", connection);
                    connection.Open();
                    MySqlDataReader MyReader;
                    MyReader = cmd.ExecuteReader();
                    while (MyReader.Read()) { }



                }
                else if (!hasRows)
                {
                      
                    

                   

                }
                connection.Close(); 
            } 
        }





        #endregion

        #endregion
        #endregion

    }
}
