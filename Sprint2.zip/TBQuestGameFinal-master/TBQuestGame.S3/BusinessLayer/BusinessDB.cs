﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TBQuestGame.BusinessLayer
{
    public class BusinessDB
    {
        public static DataLP.MySQL mysql;
        public BusinessDB()
        {
            DataLP.MySQL mysql = new DataLP.MySQL();
        }
    }
}
