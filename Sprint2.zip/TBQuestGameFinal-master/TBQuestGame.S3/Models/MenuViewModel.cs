﻿using DataLP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using TBQuestGame.PresentationLayer;

namespace TBQuestGame.Models
{
    public class MenuViewModel
    {
        public CreateAccount accountCreationWindow;
        public ManageAccount manageAccountWindow;
        GameMenuDisplay Menu;
        GameSessionViewModel viewModel;
        MySQL mysql;
        //public DataLP.MySQL mysql = new DataLP.MySQL();
        public MenuViewModel(GameSessionViewModel vm, MySQL mysql, GameMenuDisplay Menu)
        { 
            Menu.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;

            accountCreationWindow = new CreateAccount(vm, mysql);
            manageAccountWindow = new ManageAccount(vm, mysql);
            this.Menu = Menu;
            this.mysql = mysql;
            viewModel = vm;
            accountCreationWindow.DataContext = this;
        }

        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            Menu.Visibility = Visibility.Hidden;
        }


        #region CreateAccountWindowCommands
        public ICommand CreateAccountCommand
        {
            get { return new DelegateCommand(CreateAccountMethod2); }
        }




        private void CreateAccountMethod2()
        {
            if (accountCreationWindow.UsernameTxtBox.Text != "" && accountCreationWindow.PasswordTxtBox.Text != "")
            {
                mysql.Username = accountCreationWindow.UsernameTxtBox.Text;
                mysql.Password = accountCreationWindow.PasswordTxtBox.Text;

                if (mysql.CreateAccount()) { accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Red; }
                else { viewModel.PlayerUsername = mysql.Username; viewModel.Name = mysql.Username; viewModel.PlayerPassword = mysql.Password; accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Green; accountCreationWindow.UsernameTxtBox.Text = ""; accountCreationWindow.PasswordTxtBox.Text = ""; accountCreationWindow.Visibility = Visibility.Hidden; }
            }
            else
            {
                accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Red;
                accountCreationWindow.PasswordTxtBox.BorderBrush = Brushes.Red;
            }
        }
        #endregion

        #region GameMenuWindowCommands

        

        public ICommand ManageAccountCommand
        {
            get { return new DelegateCommand(ManageAccountMethod); }
        }
        public ICommand QuitCommand
        {
            get { return new DelegateCommand(QuitMethod); }
        }
        public ICommand SaveGameCommand
        {
            get { return new DelegateCommand(SaveGameMethod); }
        }
        public ICommand LoadAccountCommand
        {
            get { return new DelegateCommand(LoadAccountMethod); }
        }
        public ICommand CreateAccountWindowCommand
        {
            get { return new DelegateCommand(CreateAccountMethod); }
        }

        //
        // Save Game Method
        //
        private void SaveGameMethod()
        {

        }

        //
        // Load Account Method
        //

        private void LoadAccountMethod()
        {

        }

        //
        // Quit Application
        // 
        private void QuitMethod()
        {
            Environment.Exit(0);
        }
        //
        // Create Account
        //
        private void CreateAccountMethod()
        {
            accountCreationWindow.Show();
        }
        //
        // Manage Account
        //
        private void ManageAccountMethod()
        {
            manageAccountWindow.Show();
        }
        #endregion

    }
}
