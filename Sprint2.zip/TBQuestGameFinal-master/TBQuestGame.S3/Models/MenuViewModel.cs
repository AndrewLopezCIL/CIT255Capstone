﻿using DataLP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using TBQuestGame.PresentationLayer;

namespace TBQuestGame.Models
{
    public class MenuViewModel
    {
        public CreateAccount accountCreationWindow;
        public ManageAccount manageAccountWindow;
        public LoadAccount loadAccountWindow;
        GameMenuDisplay Menu;
        GameSessionViewModel viewModel;
        GameSessionView view;
        MySQL mysql;
        //public DataLP.MySQL mysql = new DataLP.MySQL();
        public MenuViewModel(GameSessionViewModel vm, MySQL mysql, GameMenuDisplay Menu, GameSessionView view)
        { 
            Menu.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;

            accountCreationWindow = new CreateAccount(vm, mysql);
            manageAccountWindow = new ManageAccount(vm, mysql);
            this.Menu = Menu;
            this.loadAccountWindow = new LoadAccount(vm,mysql);
            loadAccountWindow.DataContext = this;
            this.mysql = mysql;
            viewModel = vm;
            accountCreationWindow.DataContext = this;
            this.view = view;
        }

        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            Menu.Visibility = Visibility.Hidden;
        }


        #region CreateAccountWindowCommands
        public ICommand CreateAccountCommand
        {
            get { return new DelegateCommand(CreateAccountMethod2); }
        }




        private void CreateAccountMethod2()
        {
            if (accountCreationWindow.UsernameTxtBox.Text != "" && accountCreationWindow.PasswordTxtBox.Text != "")
            {
                mysql.Username = accountCreationWindow.UsernameTxtBox.Text;
                mysql.Password = accountCreationWindow.PasswordTxtBox.Text;

                if (mysql.CreateAccount()) { accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Red; }
                else { viewModel.PlayerUsername = mysql.Username; viewModel.Name = mysql.Username; viewModel.PlayerPassword = mysql.Password; accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Green; accountCreationWindow.UsernameTxtBox.Text = ""; accountCreationWindow.PasswordTxtBox.Text = ""; accountCreationWindow.Visibility = Visibility.Hidden; }
            }
            else
            {
                accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Red;
                accountCreationWindow.PasswordTxtBox.BorderBrush = Brushes.Red;
            }
        }


        private void LoadAccountMethod2()
        {
            if (loadAccountWindow.UsernameTxtBox.Text != "" && loadAccountWindow.PasswordTxtBox.Text != "")
            {
                mysql.Username = loadAccountWindow.UsernameTxtBox.Text;
                mysql.Password = loadAccountWindow.PasswordTxtBox.Text;

                if (mysql.LoadAccount()) { loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Green; viewModel.PlayerUsername = mysql.Username; viewModel.Name = mysql.Username; viewModel.PlayerPassword = mysql.Password; loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Green; loadAccountWindow.UsernameTxtBox.Text = ""; loadAccountWindow.PasswordTxtBox.Text = ""; loadAccountWindow.Visibility = Visibility.Hidden;

                    viewModel.PlayerBaseAttack = mysql.BasicAttack;
                    //viewModel.= mysql.CurrentLocation.LocationMessage;
                    viewModel.PlayerGold = mysql.Gold;
                    viewModel.PlayerHealth = mysql.Health;
                    viewModel.PlayerShield = mysql.Shield;
                    viewModel.PlayerShieldMax = mysql.ShieldMax;
                    view.AccountGiveWeapon(mysql.Weapon);

                    //
                    // Change the current location

                    viewModel.GameMap.CurrentLocationCoordinates.Row = mysql.PlayerY;
                    viewModel.GameMap.CurrentLocationCoordinates.Column= mysql.PlayerX; 
                    viewModel.PlayerXP = mysql.PlayerXP;
                    viewModel.PlayerLevel = mysql.Level; 
                    viewModel.PlayerClassString = mysql.PlayerClass;
                        viewModel.GameMap.CurrentLocation.DefaultWeaponChosen = true;
                    Location.enableControls(view);
                    view.DialogueBox.Text = viewModel.CurrentLocation.LocationMessage;
                    view.TipsBox.Text = viewModel.CurrentLocation.LocationTip;

                    viewModel.GameMap.MoveNorth();
                    viewModel.LocationLootableItems = viewModel.GameMap.CurrentLocation.LootableItems;

                    /* if (_gameSessionViewModel.GameMap.NorthLocation().Accessible && !_gameSessionViewModel.AccessibleLocations.Contains(_gameSessionViewModel.GameMap.NorthLocation()))
                    {
                        _gameSessionViewModel.AccessibleLocations.Add(_gameSessionViewModel.GameMap.NorthLocation());
                    }*/


                    view.LocationName.Text = viewModel.GameMap.CurrentLocation.Name;
                    view.DialogueBox.Text = viewModel.GameMap.CurrentLocation.LocationMessage;
                    view.ChanceOfFight();
                    view.setLocationWarningMessage(viewModel, view);

                    if (viewModel.GameMap.CurrentLocation.BossFightRoom)
                    {
                        if (!viewModel.bossesDefeated.Contains(viewModel.GameMap.CurrentLocation))
                        {
                            view.bossRoomEnterUpdate();
                        }
                    }
                    view.mapWindow.CurrentLocationDisplay.Text = viewModel.GameMap.CurrentLocation.Name;
                    view.mapWindow.LocationDescriptionDisplay.Text = viewModel.GameMap.CurrentLocation.Description;
                    view.updateAccessibleLocations();

                }
                else { loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Red; }
            }
            else
            {
                loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Red;
                loadAccountWindow.PasswordTxtBox.BorderBrush = Brushes.Red;
            }
        }
        #endregion

        #region GameMenuWindowCommands

        

        public ICommand ManageAccountCommand
        {
            get { return new DelegateCommand(ManageAccountMethod); }
        }
        public ICommand QuitCommand
        {
            get { return new DelegateCommand(QuitMethod); }
        }
        public ICommand SaveGameCommand
        {
            get { return new DelegateCommand(SaveGameMethod); }
        }
        public ICommand LoadAccountCommand
        {
            get { return new DelegateCommand(LoadAccountMethod); }
        }
        public ICommand LoadAccountCommand2
        {
            get { return new DelegateCommand(LoadAccountMethod2); }
        }
        public ICommand CreateAccountWindowCommand
        {
            get { return new DelegateCommand(CreateAccountMethod); }
        }

        //
        // Save Game Method
        //
        private void SaveGameMethod()
        {
            mysql.BasicAttack = viewModel.PlayerBaseAttack;
            mysql.Dialogue = viewModel.CurrentLocation.LocationMessage;
            mysql.Gold = viewModel.PlayerGold;
            mysql.Health = viewModel.PlayerHealth;
            mysql.Shield = viewModel.PlayerShield;
            mysql.ShieldMax = viewModel.PlayerShieldMax;
            if (viewModel.Player.EquippedWeapon == null) {
                mysql.Weapon = "Fists";
            }
            else
            {
                mysql.Weapon = viewModel.Player.EquippedWeapon.Name;
            }
            mysql.PlayerX = viewModel.GameMap.CurrentLocationCoordinates.Row;
            mysql.PlayerY = viewModel.GameMap.CurrentLocationCoordinates.Column;  
            mysql.PlayerXP = viewModel.PlayerXP;
            mysql.Level = viewModel.PlayerLevel;
            mysql.IsAlive = true;
            mysql.PlayerClass = viewModel.PlayerClassString;
            mysql.SaveAccount();
        }

        //
        // Load Account Method
        //

        private void LoadAccountMethod()
        {
            loadAccountWindow.Show();
        }

        //
        // Quit Application
        // 
        private void QuitMethod()
        {
            Environment.Exit(0);
        }
        //
        // Create Account
        //
        private void CreateAccountMethod()
        {
            accountCreationWindow.Show();
        }
        //
        // Manage Account
        //
        private void ManageAccountMethod()
        {
            manageAccountWindow.Show();
        }
        #endregion

    }
}
