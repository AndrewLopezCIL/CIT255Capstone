﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataLP;
namespace TBQuestGame.PresentationLayer
{
    /// <summary>
    /// Interaction logic for CreateAccount.xaml
    /// </summary>
    public partial class CreateAccount : Window
    {
        MySQL mysql;
        GameSessionViewModel viewModel;
        public CreateAccount(GameSessionViewModel vm, MySQL mysq)
        {
            InitializeComponent();
            WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            viewModel = vm;
            mysql = mysq;
        }
        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Visibility = Visibility.Hidden;
        }
        
        
        /*
        private void CreateAccountBTN_Click(object sender, RoutedEventArgs e)
        {
            if (UsernameTxtBox.Text != "" && PasswordTxtBox.Text != "") {
                mysql.Username = UsernameTxtBox.Text; 
                mysql.Password = PasswordTxtBox.Text;

                if (mysql.CreateAccount()) { UsernameTxtBox.BorderBrush = Brushes.Red; }
                else { viewModel.PlayerUsername = mysql.Username; viewModel.PlayerPassword = mysql.Password; UsernameTxtBox.BorderBrush = Brushes.Green; UsernameTxtBox.Text = ""; PasswordTxtBox.Text = ""; this.Hide(); }
            }
            else
            {
                UsernameTxtBox.BorderBrush = Brushes.Red;
                PasswordTxtBox.BorderBrush = Brushes.Red;
            }
            }*/
    }
}
