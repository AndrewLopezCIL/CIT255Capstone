﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TBQuestGame.PresentationLayer;

namespace TBQuestGame
{
    /// <summary>
    /// Interaction logic for GameMenuDisplay.xaml
    /// </summary>
    public partial class GameMenuDisplay : Window
    {
        public CreateAccount accountCreationWindow; 
       public DataLP.MySQL mysql = new DataLP.MySQL();
        public GameMenuDisplay(GameSessionViewModel vm)
        {
            InitializeComponent();
            WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;

           accountCreationWindow = new CreateAccount(vm);
        }

        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Visibility = Visibility.Hidden;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            accountCreationWindow.Show();
        }
    }
}
