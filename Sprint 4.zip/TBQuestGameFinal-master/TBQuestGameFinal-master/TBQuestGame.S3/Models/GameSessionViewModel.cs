﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TBQuestGame.Models;
using TBQuestGame.PresentationLayer;
using TBQuestGame.DataLayer;
using System.Windows.Media;
using TBQuestGame.Models.NPCs;
using DataLP;
using System.Windows.Input;
using TBQuestGame.Models.Items;
using System.Windows.Media.Imaging;
using System.Windows;
using System.Windows.Controls;
using TBQuestGame.Models.Enemies;

namespace TBQuestGame.PresentationLayer
{
    public class GameSessionViewModel : ObservableObject
    {
        #region FIELDS
         
        public BusinessLayer.GameBusiness business;

        public GameMenuDisplay menuWindow = new GameMenuDisplay();
        public PlayerStatsDisplay playerStatsWindow;
        public EnemyStats enemyStatsWindow = new EnemyStats();
        public MapDisplay mapWindow = new MapDisplay();
        public MenuViewModel menuViewModel;
        public GameSessionView view;
        public InventoryDisplay inventoryWindow;
        public SteelSword steelSword;
        public RubySword rubySword;
        public Excalibur excalibur;
        public Bow bow;
        public Staff staff;

        public BasicHealingPotion potion;






        // player value for Player property
        private Player _player;

        private string playerUsername;
        private string playerPassword;
        // player health value for PlayerHealth property
        private double _playerHealth;

        // player shield value for PlayerShield property
        private double _playerShield;

        // locationWarningImages value for LocationWarningImage property
        private string _locationWarningImages;

        // gameMap value for GameMap property
        private Map _gameMap;

        // current location value for CurrentLocation property
        private Location _currentLocation;

        // current location lootable items
        private ObservableCollection<Item> _currentLocationLootableItems = new ObservableCollection<Item>();

        // multiAttackLocation value for MultiAttackLocation property
        private bool _multiAttackLocation;
        // Items object being instantiated
     
        // GameData object being instantiated
        public GameData _gameData = new GameData();

        // currentEnemyID value for CurrentEnemyID property
        private int currentEnemyID;

        // currentLocationName value for CurrentLocationName property
        private string _currentLocationName;

        // accessibleLocations value for AccessibleLocations property
        public ObservableCollection<Location> _accessibleLocations = new ObservableCollection<Location>();

        // currentEnemies list for CurrentEnemies property
        public ObservableCollection<Enemy> _currentEnemies;

        // Current enemy the player's fighting's ID
        private int _currentFightingEnemyID;
        // Current enemy fighting's listplacement ID
        private int _currentFightingEnemyListPlacement;

        // For inventory binding Player's Inventory
        private ObservableCollection<Item> _playerInventory;
        // To Display Player's Name
        private string _playerName;
        // To Display Player's Level
        private int _playerLevel;
        // To Display Player's Gold
        private int _playerGold;
        // To Display Player's XP
        private double _playerXP;
        // To Display Player's Base Attack Damage
        private double _playerBaseAttack;
        // To Display Player's Skill One Damage
        private double _playerSkillOne;
        // To Display Player's Skill Two Damage
        private double _playerSkillTwo;
        // To Display Player's Skill Three Damage
        private double _playerSkillThree;
        // To Display Player's Third Eye Attack Damage
        private double _playerThirdEye;
        private string _playerClassToString;

        private TraderSid sid;

        public TraderSid Sid
        {
            get { return sid; }
            set { sid = value; OnPropertyChanged(nameof(Sid)); }
        }


        private MySQL mysqlMain = new MySQL();

        public MySQL MySQLMain
        {
            get { return mysqlMain; } 
        }


        public string PlayerUsername
        {
            get { return playerUsername; }
            set { playerUsername = value; OnPropertyChanged(nameof(PlayerUsername)); }
        }

        private bool weaponChosen;

        public bool WeaponChosen
        {
            get { return weaponChosen; }
            set { weaponChosen = value; }
        }


        public string PlayerPassword
        {
            get { return playerPassword; }
            set { playerPassword = value; }
        }



        public string PlayerClassString
        {
            get { return Player.ClassToString; }
            set { Player.ClassToString = value; OnPropertyChanged(nameof(PlayerClassString)); }
        }
        /*private void refreshNamesLists()
        {
            ItemNames = null;
            for (int item = 0; item < Player.Inventory.Count; item++)
            {
                ItemNames.Add(Player.Inventory[item].Name);
                ItemQuantities.Add(Player.Inventory[item].ItemStackCount);
            }
            
        }
        */
        public ObservableCollection<Item> PlayerInventory
        {
            get { return Player.Inventory; }
            set { Player.Inventory = value; OnPropertyChanged(nameof(PlayerInventory));  }
        }
         

            /*   private ObservableCollection<string> _itemNames = new ObservableCollection<string>(); 
               public ObservableCollection<string> ItemNames
               {
                   get { return _itemNames; }
                   set { _itemNames = value; OnPropertyChanged(nameof(ItemNames)); }
               }
               private ObservableCollection<int> _itemQuant = new ObservableCollection<int>();
               public ObservableCollection<int> ItemQuantities
               {
                   get { return _itemQuant; }
                   set { _itemQuant = value; OnPropertyChanged(nameof(ItemQuantities)); }
               }*/
               public ObservableCollection<Item> PlayerEquippedItems
               {
                   get { return Player.EquippedItems; }
                   set { Player.EquippedItems = value; OnPropertyChanged(nameof(PlayerEquippedItems)); }
               }
              
            public int PlayerLevel
        {
            get { return Player.Level; }
            set { Player.Level = value; OnPropertyChanged(nameof(PlayerLevel)); }
        }
        private double playerShieldMax;
        public double PlayerShieldMax
        {
            get { return Player.PlayerShieldMax; }
            set { Player.PlayerShieldMax = value;  OnPropertyChanged(nameof(PlayerShieldMax)); }
        }
         
        public int PlayerGold
        {
            get { return Player.Gold; }
            set { Player.Gold = value; OnPropertyChanged(nameof(PlayerGold)); }
        }
        public double PlayerXP
        {
            get { return Player.XP; }
            set { Player.XP = value; OnPropertyChanged(nameof(PlayerXP)); }
        }
        public double PlayerBaseAttack
        {
            get { return _playerBaseAttack; }
            set { _playerBaseAttack = value; OnPropertyChanged(nameof(PlayerBaseAttack)); }
        }
        public double PlayerSkillOne
        {
            get { return _playerSkillOne; }
            set { _playerSkillOne = value; OnPropertyChanged(nameof(PlayerSkillOne)); }
        }
        public double PlayerSkillTwo
        {
            get { return _playerSkillTwo; }
            set { _playerSkillTwo = value; OnPropertyChanged(nameof(PlayerXP)); }
        }
        public double PlayerSkillThree
        {
            get { return _playerSkillThree; }
            set { _playerSkillThree = value; OnPropertyChanged(nameof(PlayerXP)); }
        }
        public double PlayerThirdEye
        {
            get { return _playerThirdEye; }
            set { _playerThirdEye = value; OnPropertyChanged(nameof(PlayerXP)); }
        }
        public string Name
        {
            get { return Player.Name; }
            set { Player.Name = value; OnPropertyChanged(nameof(Name)); }
        }
        public double MaxPlayerXP
        {
            get { return Player.MaxLevelXPRange; }
            set { _maxPlayerXP = value; OnPropertyChanged(nameof(MaxPlayerXP)); }
        }
        public double MinPlayerXP
        {
            get { return Player.MinLevelXPRange; }
            set { _minPlayerXP = value; OnPropertyChanged(nameof(MinPlayerXP)); }
        }
        

        //
        // CurrentFightingEnemyID property
        // used for getting the current selected enemy's ID
        // set when player selects enemies from the list
        //
        public int CurrentFightingEnemyID
        {
            get { return _currentFightingEnemyID; }
            set { _currentFightingEnemyID = value; OnPropertyChanged(nameof(CurrentFightingEnemyID)); }
        }
        public int CurrentFightingEnemyListPlacement
        {
            get { return _currentFightingEnemyListPlacement; }
            set { _currentFightingEnemyListPlacement = value; OnPropertyChanged(nameof(CurrentFightingEnemyListPlacement)); }
        }
        //
        // used to stop a reoccuring boss battle when user goes back to location
        //
        public List<Location> bossesDefeated = new List<Location>();
        private int _missionLength = 0;
        //
        // List of current enemies battling, this is binded and used to display the list of enemies in the
        // ActiveEnemies ListBox controls
        //
        public ObservableCollection<Enemy> CurrentEnemies
        {
            get { return _currentEnemies; }
            set { _currentEnemies = value;  OnPropertyChanged(nameof(CurrentEnemies)); }
        }
        private Enemy _selectingEnemy;
        public Enemy SelectingEnemy
        {
            get { return _selectingEnemy; }
            set { _selectingEnemy = value; OnPropertyChanged(nameof(SelectingEnemy)); }
        }
        //
        // Going to be removed in the future
        //
        public int MissionLength
        {
            get { return _missionLength; }
            set { _missionLength = value; }
        }
        //
        // Current Enemy Stats
        //
        private string _enemyName;
        public string EnemyName
        {
            get { return _enemyName; }
            set { Player.currentlyAttacking.Name = value; _enemyName = value;  OnPropertyChanged(nameof(EnemyName)); }
        }
        private double _enemyHealth;
        public double EnemyHealth
        {
            get { return _enemyHealth; }
            set{ Player.currentlyAttacking.Health = value; _enemyHealth = value; OnPropertyChanged(nameof(EnemyHealth)); }
        }
        private double _enemyDamage;
        public double EnemyDamage
        {
            get { return _enemyDamage; }
            set { Player.currentlyAttacking.BaseAttack = value; _enemyDamage = value;  OnPropertyChanged(nameof(EnemyDamage)); }
        }
        private int _enemyLevel;
        public int EnemyLevel
        {
            get { return _enemyLevel; }
            set { Player.currentlyAttacking.Level = value; _enemyLevel = value; OnPropertyChanged(nameof(EnemyLevel)); }
        }

        //
        // Gets the current enemy's ID 
        // This is used to track which enemies are which, increments everytime an enemy is instantiated
        // Going to be used to track which enemy in the list gets hurt when they're selected in ActiveEnemies control
        //
        public int CurrentEnemyID
        {
            get { return currentEnemyID; }
            set { currentEnemyID = value; OnPropertyChanged(nameof(CurrentEnemyID)); }
        }
        //
        // Get warning message for the area ( For MAP DISPALY )
        //
        public string LocationWarningMessage
        {
            get { return this.CurrentLocation.LocationWarningMessage; }
            set { this.CurrentLocation.LocationWarningMessage = value; OnPropertyChanged(nameof(LocationWarningMessage)); }
        }

        //
        // AccessibleLocations is used to store all of the locations that the player can access
        //
        public ObservableCollection<Location> AccessibleLocations
        {
            get { return _accessibleLocations; }
            set { _accessibleLocations = value; OnPropertyChanged(nameof(AccessibleLocations)); }
        }
        //
        // Returns the current Location's name
        //
        public string CurrentLocationName
        {
            get { return _currentLocationName; }
            set { _currentLocationName = value; OnPropertyChanged(nameof(CurrentLocationName)); }
        }
        //
        // Returns the player's current Location
        //
        public Location CurrentLocation
        {
            get { return _currentLocation; }
            set { _currentLocation = value; OnPropertyChanged(nameof(CurrentLocation)); }
        }
        //
        // Location's Lootable Items
        // 

        public ObservableCollection<Item> LocationLootableItems
        {
            get { return GameMap.CurrentLocation.LootableItems; }
            set { GameMap.CurrentLocation.LootableItems = value; OnPropertyChanged(nameof(LocationLootableItems)); }
        }
       


        //
        // Returns messages for the current Location
        //
        private List<string> _messages;
        #endregion

        #region PROPERTIES
        // Test
        // Gets / Sets the current GameMap
        //
        public Map GameMap
        {
            get { return _gameMap; }
            set { _gameMap = value; }
        }
        //
        // Gets / Set the current player
        //
        public Player Player
        {
            get { return _player; }
            set { _player = value; }
        } 
        //
        // Used to determine which enemy is currently selected on the ListBox ActiveEnemies
        //
        private bool _enemySelected;
        private double _maxPlayerXP;
        private double _minPlayerXP;

        public bool EnemySelected
        {
            get { return _enemySelected; }
            set { _enemySelected = value; OnPropertyChanged(nameof(EnemySelected)); }
        }

        //
        // Return the list of strings converted to a single string
        // with new lines between each message
        //
        public string Messages
        {
            get { return string.Join("\n\n",_messages); }
        }
        
        //
        // Gets / Sets the player's health
        //
        public double PlayerHealth
        {
            get { return _playerHealth; }
            set { _playerHealth = value; OnPropertyChanged(nameof(PlayerHealth)); }
        }
        //
        // Gets / Sets the player's shield
        //
        private string weaponname;

        public string NameOfWeapon
        {
            get { return Player.EquippedWeapon.Name; } 
        }



        public double PlayerShield
        {
            get { return _playerShield; }
            set { _playerShield = value; OnPropertyChanged(nameof(PlayerShield)); }
        }

        private string _locationMessage;
        public string LocationMessage
        {
            get { return GameMap.CurrentLocation.LocationMessage; }
            set { GameMap.CurrentLocation.LocationMessage = value; OnPropertyChanged(nameof(LocationMessage)); }
        }
        public ObservableCollection<Item> CurrentLocationMarket
        {
            get { return sid.Buyables; }
            set { sid.Buyables = value; OnPropertyChanged(nameof(CurrentLocationMarket)); }
        }
       
        public Item SelectedMarketItem { get; set; }
        #endregion

        #region METHODS 
        public void SelectedEnemySetter(int selected, GameSessionView gsv)
        {
            /*
            for (int i = 0; i < CurrentEnemies.Count; i++)
			{ 
                if (CurrentLocation.MultiAttackLocation == false)
                {
                    if (CurrentEnemies[i].SelectedToFight == false)
                    {
                        CurrentEnemies[i].stopAttackingPlayer();
                        gsv.DialogueBox.Text = "Stopped attacking player";
                    }
                }
                else if (CurrentLocation.MultiAttackLocation == true)
                {
                    if (CurrentEnemies[i].SelectedToFight == false)
                    {
                        CurrentEnemies[i].stopAttackingPlayer();
                       CurrentEnemies[i].startAttackingPlayer();
                    }
                }
            }*/
            EnemySelected = true;  
            //
            // Most likely where the stacked damage problem is occuring
            //
            for (int i = 0; i < CurrentEnemies.Count; i++)
			{ 

                CurrentEnemies[i].refreshAllEnemiesPositions();
                if (CurrentEnemies[i].listPlacement == selected)
                { 
                        CurrentFightingEnemyID = CurrentEnemies[i].ID;
                        CurrentFightingEnemyListPlacement = CurrentEnemies[i].listPlacement;

                        Player.currentlyAttacking = CurrentEnemies[i];

                        SelectingEnemy = CurrentEnemies[i];
                        if (CurrentEnemies[i].SelectedToFight == false)
                        {
                            CurrentEnemies[i].AttackingPlayer = true;

                           CurrentEnemies[i].startAttackingPlayer();

                            gsv.EnemyPicture.Source = CurrentEnemies[i].PictureSource;
                        this.enemyStatsWindow.EnemyStatsPicture.Source = CurrentEnemies[i].PictureSource;
                            CurrentEnemies[i].SelectedToFight = true;
                        EnemyDamage = CurrentEnemies[i].BaseAttack;
                        EnemyName = CurrentEnemies[i].Name;
                        EnemyHealth = CurrentEnemies[i].Health;
                        EnemyLevel =CurrentEnemies[i].Level;
                        gsv.EnemyHealthDisplay.Visibility = System.Windows.Visibility.Visible;
                        this.enemyStatsWindow.EnemyStatsPicture.Visibility = System.Windows.Visibility.Visible;
                        gsv.EnemyHealthDisplay.Maximum = CurrentEnemies[i].MaxHealth;
                        gsv.EnemyHealthDisplay.Value = CurrentEnemies[i].Health;
                        gsv.EnemyHealthDisplay.Minimum = 0;
                        
                        }
                        else
                        {
                            CurrentEnemies[i].SelectedToFight = true;
                        }
                 }
                else if (CurrentEnemies[i].listPlacement != selected)
                {
                    if (CurrentEnemies[i].listPlacement != selected && CurrentEnemies[i].SelectedToFight == true)
                    {
                        CurrentEnemies[i].SelectedToFight = false;
                        CurrentEnemies[i].AttackingPlayer = false;
                        CurrentEnemies[i].stopAttackingPlayer();
                    }
                    else
                    {
                        CurrentEnemies[i].SelectedToFight = false;
                    } 
                }
            } 
        }

        //
        // Replaced Methods from view
        //

        public BitmapImage getPictureSource(string picturePath)
        {
            BitmapImage bitImages = new BitmapImage();
            bitImages.BeginInit();
            bitImages.UriSource = new Uri("/Images/" + picturePath, UriKind.Relative);
            bitImages.EndInit();

            return bitImages;
        }

        public int getPlacementID(Enemy enemyPassed)
        {
            int id = 0;
            for (int position = 0; position < this.CurrentEnemies.Count; position++)
            {
                if (this.CurrentEnemies[position].ID == enemyPassed.ID)
                {
                    id = position;
                    break;
                }

            }
            return id;
        }

        public void setEnemy(string enemy, Enemy enemy2)
        {
             
        }

        public void bossRoomEnterUpdate()
        {
            this.PlayerShield += 35;
            BossBattleStart();
            view.LocationName.Text = this.GameMap.CurrentLocation.Name;
            view.DialogueBox.Text = this.GameMap.CurrentLocation.LocationMessage;
            this.LocationWarningMessage = this.CurrentLocation.LocationWarningMessage;
            Location.disableControls(view);
        }

         
        public void setLocationWarningMessage()
        {
            if (this.GameMap.CurrentLocation.MultiAttackLocation == true)
            {
                this.mapWindow.WarningDisplay.Text = "Dangerous area!";
            }
            else if (this.GameMap.CurrentLocation.BossFightRoom)
            {
                this.mapWindow.WarningDisplay.Text = "[BOSS] Location-Freeze!";
            }
            else if (this.GameMap.CurrentLocation.MultiAttackLocation == false)
            {
                this.mapWindow.WarningDisplay.Text = "Moderate Area!";
            }
        }




        public void MovementValidity()
        {
            this.LocationLootableItems = this.GameMap.CurrentLocation.LootableItems;




            view.LocationName.Text = this.GameMap.CurrentLocation.Name;
            view.DialogueBox.Text = this.GameMap.CurrentLocation.LocationMessage;
             this.ChanceOfFight();
            this.setLocationWarningMessage();

            if (this.GameMap.CurrentLocation.BossFightRoom)
            {
                if (!this.bossesDefeated.Contains(this.GameMap.CurrentLocation))
                {
                    this.bossRoomEnterUpdate();
                }
            }
            mapWindow.CurrentLocationDisplay.Text = this.GameMap.CurrentLocation.Name;
            mapWindow.LocationDescriptionDisplay.Text = this.GameMap.CurrentLocation.Description;

        }




        #endregion

        #region Commands


        public ICommand NorthButtonCommand
        {
            get { return new DelegateCommand(NorthButtonMethod); }
        }
        public ICommand EastButtonCommand
        {
            get { return new DelegateCommand(EastButtonMethod); }
        }
        public ICommand WestButtonCommand
        {
            get { return new DelegateCommand(WestButtonMethod); }
        }
        public ICommand SouthButtonCommand
        {
            get { return new DelegateCommand(SouthButtonMethod); }
        }
        public ICommand MapWindowCommand
        {
            get { return new DelegateCommand(MapWindowMethod); }
        }
        public ICommand MenuWindowCommand
        {
            get { return new DelegateCommand(MenuWindowMethod); }
        }
        public ICommand InventoryWindowCommand
        {
            get { return new DelegateCommand(InventoryWindowMethod); }
        }
        public ICommand ExitCommand
        {
            get { return new DelegateCommand(ExitGameMethod); }
        }
        public ICommand PlayerStatsCommandWindow
        {
            get { return new DelegateCommand(PlayerStatsWindowMethod); }
        }
        public ICommand EnemyStatsCommandWindow
        {
            get { return new DelegateCommand(EnemyStatsWindowMethod); }
        }
        public ICommand SkillsCommand
        {
            get { return new DelegateCommand(SkillsMethod); }
        }
        public ICommand AttackCommand
        {
            get { return new DelegateCommand(AttackMethod); }
        }
        public ICommand BuyCommand
        {
            get { return new DelegateCommand(BuyMethod); }
        }

        private void SkillsMethod()
        {
            //potion.potionUsedWithCooldown(_gameSessionViewModel);
            AddEnemyToList("warrior-black");
            AddEnemyToList("warrior");
            AddEnemyToList("wizard");
            AddEnemyToList("bandit");
        }

        private void InventoryWindowMethod()
        {
            inventoryWindow.Visibility = Visibility.Visible;
            Location.enableControls(view);
        }


        public void EnemyStatsWindowMethod()
        {
            enemyStatsWindow.Visibility = Visibility.Visible;
        }
        public void PlayerStatsWindowMethod()
        {
            playerStatsWindow.Visibility = Visibility.Visible;
        }
        private void ExitGameMethod()
        {
            Environment.Exit(0);
        }



        public void AddEnemyToList(string enemyName)
        {
            string nameOfEnemy = "";
            string levelOfEnemy = "";
            string enemyPicturePath = "";
            bool isBoss = false;
            Enemy enemy;
            switch (enemyName.ToLower())
            {
                case "warrior":
                    Warrior warrior = new Warrior(true, this, view);
                    warrior.RemovedFromActiveEnemiesList = false;
                    this.Player.PlayersCurrentState = Player.PlayerState.Fighting;
                    warrior.AttackingPlayer = true;
                    enemy = warrior;
                    this.CurrentEnemies.Add(warrior);
                    nameOfEnemy = "Warrior";
                    levelOfEnemy = "{LVL " + warrior.Level + " }";
                    enemyPicturePath = warrior.Image;
                    warrior.listPlacement = this.getPlacementID(warrior);
                    warrior.PictureSource = this.getPictureSource(enemyPicturePath);
                    break;
                case "warrior-black":

                    BlackKnight blackKnight = new BlackKnight(false, this, view);
                    this.CurrentEnemies.Add(blackKnight);
                    enemy = blackKnight;
                    blackKnight.AttackingPlayer = true;
                    this.Player.PlayersCurrentState = Player.PlayerState.Fighting;
                    nameOfEnemy = blackKnight.Name;
                    levelOfEnemy = "{LVL " + blackKnight.Level + " }";
                    blackKnight.IsBoss = true;
                    isBoss = true;
                    enemyPicturePath = blackKnight.Image;
                    blackKnight.listPlacement = this.getPlacementID(blackKnight);
                    blackKnight.PictureSource = this.getPictureSource(enemyPicturePath);

                    break;
                case "bandit":
                    Bandit bandit = new Bandit(false, this, view);
                    bandit.RemovedFromActiveEnemiesList = false;
                    this.Player.PlayersCurrentState = Player.PlayerState.Fighting;
                    bandit.AttackingPlayer = true;
                    enemy = bandit;
                    this.CurrentEnemies.Add(bandit);
                    nameOfEnemy = "Bandit";
                    levelOfEnemy = "{LVL " + bandit.Level + " }";
                    enemyPicturePath = bandit.Image;
                    bandit.listPlacement = this.getPlacementID(bandit);
                    bandit.PictureSource = this.getPictureSource(enemyPicturePath);

                    break;
                case "mudcrawler":
                    nameOfEnemy = "MudCrawler";
                    levelOfEnemy = "{LVL 9}";
                    enemyPicturePath = "MudCrawler.png";
                    break;
                case "scuffedspider":
                    nameOfEnemy = "Spider";
                    levelOfEnemy = "{LVL 3}";
                    enemyPicturePath = "scuffedspider.png";
                    break;
                case "wizard":
                    Wizard wizard = new Wizard(false, this, view);
                    wizard.RemovedFromActiveEnemiesList = false;
                    this.Player.PlayersCurrentState = Player.PlayerState.Fighting;
                    wizard.AttackingPlayer = true;
                    enemy = wizard;
                    this.CurrentEnemies.Add(wizard);
                    nameOfEnemy = "Wizard";
                    levelOfEnemy = "{LVL " + wizard.Level + " }";
                    enemyPicturePath = wizard.Image;
                    wizard.listPlacement = this.getPlacementID(wizard);
                    wizard.PictureSource = this.getPictureSource(enemyPicturePath);
                    break;
                default:
                    break;
            }
            ListBoxItem item = new ListBoxItem();
            StackPanel new_item = new StackPanel();
            new_item.Orientation = Orientation.Horizontal;
            Image img = new Image();
            BitmapImage bitImage = new BitmapImage();
            bitImage.BeginInit();

            bitImage.UriSource = new Uri("/Images/" + enemyPicturePath, UriKind.Relative);

            bitImage.EndInit();

            img.Source = bitImage;
            //
            // Flip image
            //


            view.EnemyPicture.Source = bitImage;

            img.Width = 32;
            img.Height = 32;

            TextBlock entityLevel = new TextBlock();
            entityLevel.Text = levelOfEnemy;
            entityLevel.FontWeight = FontWeights.Bold;
            entityLevel.FontSize = 16;
            entityLevel.VerticalAlignment = VerticalAlignment.Center;

            TextBlock entityName = new TextBlock();
            entityName.Text = nameOfEnemy;
            entityName.FontSize = 15.5;
            entityName.FontWeight = FontWeights.Bold;
            entityName.VerticalAlignment = VerticalAlignment.Center;

            new_item.Children.Add(img);
            new_item.Children.Add(entityLevel);
            new_item.Children.Add(entityName);
            item.Content = new_item;
            if (!isBoss)
            {
                item.Background = Brushes.Red;
            }
            else if (isBoss == true)
            {
                item.Background = Brushes.Pink;
            }
            item.BorderBrush = Brushes.Black;
            item.BorderThickness = new Thickness(3, 3, 3, 0);

         view.ActiveEnemies.Items.Add(item);

        }



        public void changePlayerClass(string userClass)
        {
            switch (userClass.ToLower())
            {
                case "warrior":
                    BitmapImage playerBitImage2 = new BitmapImage();
                    playerBitImage2.BeginInit();

                    playerBitImage2.UriSource = new Uri("/Images/warrior-icon.png", UriKind.Relative);

                    playerBitImage2.EndInit();
                    view.PlayerPicture.Source = playerBitImage2;
                    this.Player.ClassTypeProp = Player.ClassType.Warrior;
                    this.Player.ClassToString = "Warrior";
                    break;
                case "archer":
                    BitmapImage playerBitImage3 = new BitmapImage();
                    playerBitImage3.BeginInit();

                    playerBitImage3.UriSource = new Uri("/Images/archer-icon.png", UriKind.Relative);

                    playerBitImage3.EndInit();
                    view.PlayerPicture.Source = playerBitImage3;
                    this.Player.ClassTypeProp = Player.ClassType.Archer;
                    this.Player.ClassToString = "Archer";
                    break;
                case "mage":
                    BitmapImage playerBitImage4 = new BitmapImage();
                    playerBitImage4.BeginInit();

                    playerBitImage4.UriSource = new Uri("/Images/mage-icon.png", UriKind.Relative);

                    playerBitImage4.EndInit();
                    view.PlayerPicture.Source = playerBitImage4;
                    this.Player.ClassTypeProp = Player.ClassType.Mage;
                    this.Player.ClassToString = "Mage";
                    break;

                default:
                    break;
            }

        }
        public void BossBattleStart()
        {
            switch (this.GameMap.CurrentLocation.Name)
            {
                case "The Dark Forest":
                   AddEnemyToList("wizard");
                    this.bossesDefeated.Add(this.GameMap.CurrentLocation);
                    break;
                case "Vickren Dungeon":
                   AddEnemyToList("warrior");
                    this.bossesDefeated.Add(this.GameMap.CurrentLocation);
                    break;
                case "Kardon Dungeon":
                   AddEnemyToList("bandit");
                    this.bossesDefeated.Add(this.GameMap.CurrentLocation);
                    break;
                default:
                    break;
            }
        }


        public void ChanceOfFight()
        {
            if (this.GameMap.CurrentLocation.ChanceOfFight == true)
            {
                int chance;
                Random fightChance = new Random();
                Random willFight = new Random();
                int willFightEnemy = willFight.Next(2);
                ObservableCollection<string> enemyNames = new ObservableCollection<string>();
                enemyNames.Add("Bandit");
                enemyNames.Add("warrior-black");
                enemyNames.Add("Warrior");
                enemyNames.Add("Wizard");
                switch (willFightEnemy)
                {
                    case 0:
                        break;
                    case 1:
                        chance = fightChance.Next(4);

                        if (chance == 1)
                        {
                            AddEnemyToList(enemyNames[1]);

                        }
                        else if (chance == 2)
                        {
                            AddEnemyToList(enemyNames[2]);

                        }
                        else if (chance == 3 && this.Player.Level > 2)
                        {
                            AddEnemyToList(enemyNames[3]);
                        }
                        else if (chance == 0)
                        {
                          AddEnemyToList(enemyNames[0]);

                        }
                        break;
                    default:
                        break;
                }



            }
        }




        public void AttackMethod()
        {
            this.Player.AttackEnemy(this, view, Player.AttackType.BasicAttack);
        }


        public void BuyMethod()
        {
            for (int item = 0; item < sid.Buyables.Count; item++)
            {
                if (sid.Buyables[item].HasListSelection == true)
                {
                    //If player has enough for purchasing the item in the shop
                    if (this.Player.Gold >= sid.Buyables[item].Value)
                    {
                        this.Player.Inventory.Add(sid.Buyables[item]);
                        this.PlayerGold -= sid.Buyables[item].Value;
                        sid.ThanksForBuying();
                        break;
                    }
                    else if (this.Player.Gold < sid.Buyables[item].Value)
                    {
                        
                        sid.NotEnoughGold();
                        break;
                    }
                }
                else
                {
                    sid.Buyables[item].HasListSelection = false;
                }
            }
        }
        public void enteredSidsShop()
        {
            if (this.GameMap.CurrentLocation.InSidShop == true)
            {

                view.Market.IsEnabled = true;
                view.MarketLabel.IsEnabled = true;
                view.Market.Visibility = Visibility.Visible;
                view.Buy.Visibility = Visibility.Visible;
            }
            else if (this.GameMap.CurrentLocation.InSidShop != true)
            {
                view.Market.IsEnabled = false;
                view.MarketLabel.IsEnabled = false;
                view.Market.Visibility = Visibility.Hidden;
                view.Buy.Visibility = Visibility.Hidden;
            }
        }

        public void updateAccessibleLocations()
        {
            this.AccessibleLocations.Clear();
            if (this.GameMap.CurrentLocation.Name == "Yin Village" && this.GameMap.CurrentLocation.DefaultWeaponChosen == true)
            {
                this.GameMap.CurrentLocation.ChanceOfFight = true;
                this.GameMap.CurrentLocation.LocationMessage = "You look around and see the bandits have completely\ntaken over, and one of them rushes towards you!";
            }
            else if (this.GameMap.CurrentLocation.Name == "Yin Village" && this.GameMap.CurrentLocation.DefaultWeaponChosen == false)
            {
                Location.disableControls(view);

            }
            view.TipsBox.Foreground = Brushes.Black;
            view.TipsBox.FontWeight = FontWeights.Bold;
            view.TipsBox.FontSize = 15;
            if (this.GameMap.CurrentLocation.LocationTip != "" && this.GameMap.CurrentLocation.LocationTip != null)
            {
                view.TipsBox.Text = this.GameMap.CurrentLocation.LocationTip;
            }

            if (this.GameMap.NorthLocation() != null)
            {
                this.GameMap.NorthLocation().Direction = "North";
                this.AccessibleLocations.Add(this.GameMap.NorthLocation());
                view.DialogueBox.Foreground = Brushes.Black;
                view.DialogueBox.FontWeight = FontWeights.Bold;
                view.DialogueBox.FontSize = 15;
            }
            if (this.GameMap.EastLocation() != null)
            {
                this.GameMap.EastLocation().Direction = "East";

                this.AccessibleLocations.Add(this.GameMap.EastLocation());
                view.DialogueBox.Foreground = Brushes.Black;
                view.DialogueBox.FontWeight = FontWeights.Bold;
                view.DialogueBox.FontSize = 15;

            }
            if (this.GameMap.WestLocation() != null)
            {
                this.GameMap.WestLocation().Direction = "West";

                this.AccessibleLocations.Add(this.GameMap.WestLocation());
                view.DialogueBox.Foreground = Brushes.Black;
                view.DialogueBox.FontWeight = FontWeights.Bold;
                view.DialogueBox.FontSize = 15;

            }
            if (this.GameMap.SouthLocation() != null)
            {
                this.GameMap.SouthLocation().Direction = "South";

                this.AccessibleLocations.Add(this.GameMap.SouthLocation());
                view.DialogueBox.Foreground = Brushes.Black;
                view.DialogueBox.FontWeight = FontWeights.Bold;
                view.DialogueBox.FontSize = 15;

            }
        }
        public void LastValidity()
        {
            if (this.GameMap.CurrentLocation.LocationTip != "" && this.GameMap.CurrentLocation.LocationTip != null)
            {
                view.TipsBox.Text = this.GameMap.CurrentLocation.LocationTip;
            }

            this.updateAccessibleLocations();
            this.enteredSidsShop();
        }
        private void NorthButtonMethod()
        {
            if (this.GameMap.NorthLocation() != null)
            {

                this.GameMap.MoveNorth();

                this.MovementValidity();

            }
           LastValidity();
        }
        private void EastButtonMethod()
        {
            if (this.GameMap.EastLocation() != null)
            {

                this.GameMap.MoveEast();

                this.MovementValidity();

            }
          LastValidity();
        }
        private void SouthButtonMethod()
        {
            if (this.GameMap.SouthLocation() != null)
            {

                this.GameMap.MoveSouth();

                this.MovementValidity();

            }
           LastValidity();
        }
        private void WestButtonMethod()
        {
            if (this.GameMap.WestLocation() != null)
            {

                this.GameMap.MoveWest();

                this.MovementValidity();

            }
           LastValidity();
        } 
        private void MapWindowMethod()
        {
            mapWindow.Visibility = Visibility.Visible;
            mapWindow.DataContext = this;
        }
        private void MenuWindowMethod()
        {
            menuWindow.Visibility = Visibility.Visible;

        }
       
        public void BuyVisible(int i)
        {
            if (i == 0)
            {
                view.Buy.Visibility = Visibility.Visible;
            }
            else if (i==1)
            {
                view.Buy.Visibility = Visibility.Hidden;

            }
        }

        public void keyArgs(object sender, KeyEventArgs e)
        {

        }

        public void viewCall()
        {


            menuViewModel = new MenuViewModel(this, this.MySQLMain, this.menuWindow, view);

            this.menuWindow.DataContext = menuViewModel;


            view.ActiveEnemies.DataContext = this.CurrentEnemies;

            view.DataContext = this;

            inventoryWindow = new InventoryDisplay(this, view);

            inventoryWindow.DataContext = this;
            potion = new BasicHealingPotion(this, view);
            sid = new TraderSid(this, view);


            sid.AddBuyables();

            this.Sid = sid;

            this.AccessibleLocations.Clear();

            this.updateAccessibleLocations();
        }


        public void LocationNameTextChanged()
        {
            if (this.GameMap.CurrentLocation.ExceptionRoom == true)
            {
                this.GameMap.CurrentLocation.ExceptionRoom = false;
            }
            else
            {
                view.TipsBox.Text = "";
            }
        }

        public void MarketSelectionChanged(object sender)
        {
            var item = (DataGrid)sender;
            for (int fixIndex = 0; fixIndex < this.Sid.Buyables.Count; fixIndex++)
            {
                if (this.Sid.Buyables[fixIndex].HasListSelection == true)
                {
                    this.Sid.Buyables[fixIndex].HasListSelection = false;
                    this.SelectedMarketItem = null;
                }
            }
            this.SelectedMarketItem = this.Sid.Buyables[item.SelectedIndex];
            this.Sid.Buyables[item.SelectedIndex].HasListSelection = true;

        }

        public void CommandKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) { 
                if (this.GameMap.CurrentLocation.Name == "Yin Village" && this.GameMap.CurrentLocation.DefaultWeaponChosen == false)
                {
                    this.bow.Name = "Bow";
                    this.staff.Name = "Magic Staff";
                    switch (view.CommandBox.Text.ToLower())
                    {
                        case "/grab sword":
                            view.TipsBox.Text = "You grab the Sword!";
                            Location.enableControls(view);
                            view.CommandBox.Foreground = Brushes.Black;
                            view.CommandBox.Text = "";
                            this.GameMap.CurrentLocation.DefaultWeaponChosen = true;
                            this.GameMap.CurrentLocation.ChanceOfFight = true;
                            view.TipsBox.Text = "You're not strong, venture out and become stronger!";
                            this.Player.EquippedItems.Add(this.steelSword);
                            this.Player.EquippedWeapon = this.steelSword;
                            this.MySQLMain.WeaponChosen = true;
                            this.changePlayerClass("Warrior");
                            this.playerStatsWindow.PlayerClass.Text = "Warrior";

                            view.DialogueBox.Text = "Where should I go now?";
                            break;
                        case "/grab bow":
                            view.TipsBox.Text = "You grab the Bow!";
                            Location.enableControls(view);
                            view.CommandBox.Foreground = Brushes.Black;
                            view.CommandBox.Text = "";
                            this.GameMap.CurrentLocation.DefaultWeaponChosen = true;
                            this.GameMap.CurrentLocation.ChanceOfFight = true;
                            view.TipsBox.Text = "You're not strong, venture out and become stronger!";
                            this.playerStatsWindow.PlayerClass.Text = "Archer";
                            this.Player.EquippedItems.Add(this.bow);
                            this.Player.EquippedWeapon = this.bow;
                            this.MySQLMain.WeaponChosen = true;

                            this.changePlayerClass("Archer");
                            view.DialogueBox.Text = "Where should I go now?";

                            break;
                        case "/grab staff":
                            view.TipsBox.Text = "You grab the Magic Staff!";
                            Location.enableControls(view);
                            view.CommandBox.Foreground = Brushes.Black;
                            view.CommandBox.Text = "";
                            this.GameMap.CurrentLocation.DefaultWeaponChosen = true;
                            this.GameMap.CurrentLocation.ChanceOfFight = true;
                            view.TipsBox.Text = "You're not strong, venture out and become stronger!";
                            this.Player.EquippedItems.Add(this.staff);
                            this.Player.EquippedWeapon = this.staff;
                            this.MySQLMain.WeaponChosen = true;

                            this.playerStatsWindow.PlayerClass.Text = "Mage";

                            this.changePlayerClass("Mage");
                            view.DialogueBox.Text = "Where should I go now?";

                            break;
                        default:
                            view.CommandBox.Foreground = Brushes.Red;
                            break;
                    }
                }
            }
        }
        public void ActiveEnemySelectedChanged(object sender)
        {
            var item = (ListBox)sender;
            this.SelectedEnemySetter(item.SelectedIndex, view);
        }
        #endregion


        #region CONSTRUCTORS
        public GameSessionViewModel()
        {

        }
        //
        // Constructor used for setting the current properties values
        //
        public GameSessionViewModel(Player player, List<string>initialMessages, Map gameMap, GameMapCoordinates currentLocationCoordinates, ObservableCollection<Enemy> currentEnemies, BusinessLayer.GameBusiness businessLayer)
        {

            this.business = businessLayer;
            staff = new Staff(this);

                steelSword = new SteelSword(this);
          rubySword = new RubySword(this);
         excalibur = new Excalibur(this);
          bow = new Bow(this);
            enemyStatsWindow.DataContext = this;

            playerStatsWindow = new PlayerStatsDisplay(this);
            playerStatsWindow.DataContext = this;







            








            // sets the player's inventory
            _playerInventory = player.Inventory;

            
            // sets the player's shield
            _playerShield = player.Shield;
             
            // sets the player's health
            _playerHealth = player.Health;
             
            // Player's XP
            _playerXP = player.XP;

            // Max Player XP
            _maxPlayerXP = player.MaxLevelXPRange;
          
            // Player's Level
            _playerLevel = player.Level;

            // Player's Gold
            _playerGold = player.Gold;

            // Player's Base Attack
            _playerBaseAttack = player.BasicAttack;

            // Player's Skill One
            _playerSkillOne = player.SkillOneAttack;

            // Player's Skill Two
            _playerSkillTwo = player.SkillTwoAttack;

            // Player's Skill Three
            _playerSkillThree = player.SkillThreeAttack;

            // Player's Third Eye
            _playerThirdEye = player.ThirdEyeAttack;

            // Setting player class string
            //_playerClassToString =  Player.ClassTypeProp.ToString();

            if (player.currentlyAttacking != null) {
                // EnemyHealth
                _enemyHealth = player.currentlyAttacking.Health;
                // EnemyName
                _enemyName = player.currentlyAttacking.Name;
                // EnemyDamage
                _enemyDamage = player.currentlyAttacking.BaseAttack;
                // EnemyLevel
                _enemyLevel = player.currentlyAttacking.Level;
            }
            else
            {
                // EnemyHealth
                _enemyHealth = 0;
                // EnemyName
                _enemyName = "Currently Not Fighting";
                // EnemyDamage
                _enemyDamage = 0;
                // EnemyLevel
                _enemyLevel = 0;
            }
            // gets currentEnemyID from gameData, and sets the currentEnemyID variable in the view model to equal that
            currentEnemyID = _gameData.currentEnemyID;
            // gets the current enemies list that is passed and sets _currentEnemies in the view model to equal that
            _currentEnemies = currentEnemies; 
            // sets the player
            _player = player;
            // sets the messages property
            _messages = initialMessages;
            // sets the current gameMap
            _gameMap = gameMap;
            // sets the player's currentLocationCoordinates in the view model
            _gameMap.CurrentLocationCoordinates = currentLocationCoordinates;
            // sets the currentLocation to equal the gameMap's passed currentLocation
            _currentLocation = _gameMap.CurrentLocation;
            // sets the currentLocationLootableItems
            _currentLocationLootableItems = _gameMap.CurrentLocation.LootableItems;
            // sets the current locationWarningImage to the gameMap's currentLocation's warning Image
            _locationWarningImages = _gameMap.CurrentLocation.LocationWarningImage;




        }
        
        #endregion

    }
}
