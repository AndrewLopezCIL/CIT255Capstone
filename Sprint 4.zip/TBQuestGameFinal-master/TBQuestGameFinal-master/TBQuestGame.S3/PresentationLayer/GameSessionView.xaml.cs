﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TBQuestGame.PresentationLayer;
using TBQuestGame.Models;
using TBQuestGame.DataLayer;
using TBQuestGame.Models.Items;
using System.Collections.ObjectModel;
using TBQuestGame.Models.NPCs;
using TBQuestGame.Models.Enemies;
using DataLP;
namespace TBQuestGame.PresentationLayer
{
    /// <summary>
    /// Interaction logic for GameSessionView.xaml
    /// </summary>
    public partial class GameSessionView : Window
    {
        #region Constructor 
        GameSessionViewModel gsm;
        public GameSessionView(GameSessionViewModel gsm)
        {
            this.gsm = gsm;
            this.gsm.view = this; 
            InitializeComponent(); 
            gsm.viewCall();
        }
        #endregion 
        #region Left Over Events 
        private void ActiveEnemies_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            gsm.ActiveEnemySelectedChanged(sender);
        } 
        private void CommandBox_KeyDown(object sender, KeyEventArgs e)
        { 
                gsm.CommandKeyDown(sender,e); 
        } 
        private void Market_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            gsm.MarketSelectionChanged(sender);
        } 
        private void MarketLabel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            gsm.BuyVisible(0);
        } 
        private void Label_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            gsm.BuyVisible(1);
        } 
        private void LocationName_TextChanged(object sender, TextChangedEventArgs e)
        {
            gsm.LocationNameTextChanged();
            } 
        private void Window_Closed(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }

    #endregion
    }