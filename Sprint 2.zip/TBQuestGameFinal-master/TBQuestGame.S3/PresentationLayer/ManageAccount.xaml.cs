﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataLP;
namespace TBQuestGame.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ManageAccount.xaml
    /// </summary>
    public partial class ManageAccount : Window
    {
        GameSessionViewModel viewModel;
        MySQL mysql;
        public ManageAccount(GameSessionViewModel vm, MySQL mysq)
        {
            InitializeComponent();
            viewModel = vm;
            mysql = mysq;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           // mysql.CurrentUsername = viewModel.PlayerUsername;
            if (CurrentUsername.Text != "")
            {
                 
                if (mysql.UpdateAccount(CurrentUsername.Text))
                {
                    CurrentUsername.BorderBrush = Brushes.DarkRed;
                    CurrentUsername.Text = "";
                }
                else
                {
                    CurrentUsername.BorderBrush = Brushes.Green;
                    CurrentUsername.Text = "";
                    viewModel.Name = mysql.CurrentUsername;
                    viewModel.PlayerUsername = mysql.CurrentUsername;
                }

            }

        }
        //
        //Delete Account
        //
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            mysql.DeleteAccount(mysql.CurrentUsername);
        }
    }
}
