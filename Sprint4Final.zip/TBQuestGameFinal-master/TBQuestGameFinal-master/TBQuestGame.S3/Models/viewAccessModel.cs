﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TBQuestGame.PresentationLayer;
using TBQuestGame.Models;
using TBQuestGame.BusinessLayer;
using TBQuestGame.DataLayer;
namespace TBQuestGame.Models
{
    public class viewAccessModel
    {
        public GameSessionView view;
        public GameSessionViewModel viewModel;
        public viewAccessModel(GameSessionView view)
        {
            this.view = view; 
        } 
    }
}
