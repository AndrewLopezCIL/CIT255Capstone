﻿using DataLP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using TBQuestGame.PresentationLayer;

namespace TBQuestGame.Models
{
    public class MenuViewModel
    {
        public CreateAccount accountCreationWindow;
        public ManageAccount manageAccountWindow;
        public LoadAccount loadAccountWindow;

        GameMenuDisplay Menu;
        GameSessionViewModel viewModel;
        GameSessionView view;
        MySQL mysql;
        //public DataLP.MySQL mysql = new DataLP.MySQL();
        public MenuViewModel(GameSessionViewModel vm, MySQL mysql, GameMenuDisplay Menu, GameSessionView view)
        { 
            Menu.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;

            accountCreationWindow = new CreateAccount();
            manageAccountWindow = new ManageAccount();
            this.Menu = Menu;
            manageAccountWindow.DataContext = this;
            this.loadAccountWindow = new LoadAccount();
            loadAccountWindow.DataContext = this;
            this.mysql = mysql;
            viewModel = vm;
            accountCreationWindow.DataContext = this;
            this.view = view;

        }

        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            Menu.Visibility = Visibility.Hidden;
        }


        #region CreateAccountWindowCommands
        public ICommand CreateAccountCommand
        {
            get { return new DelegateCommand(CreateAccountMethod2); }
        }

       


        private void CreateAccountMethod2()
        {
            if (accountCreationWindow.UsernameTxtBox.Text != "" && accountCreationWindow.PasswordTxtBox.Text != ""&& mysql.WeaponChosen == true)
            {
                mysql.Username = accountCreationWindow.UsernameTxtBox.Text;
                mysql.Password = accountCreationWindow.PasswordTxtBox.Text;

                if (mysql.CreateAccount()) { accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Red;
                    accountCreationWindow.ErrorGrabWeapon.Content = "Account taken, try again!";
                    accountCreationWindow.ErrorGrabWeapon.Foreground = Brushes.Red;

                }
                else {
                   
                   SaveGameMethod();
                    viewModel.PlayerUsername = mysql.Username; viewModel.Name = mysql.Username; viewModel.PlayerPassword = mysql.Password; accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Green; accountCreationWindow.UsernameTxtBox.Text = ""; accountCreationWindow.PasswordTxtBox.Text = "";
                    viewModel.menuWindow.SaveButton.IsEnabled = true;
                    accountCreationWindow.ErrorGrabWeapon.Content = "Account created!";
                    accountCreationWindow.ErrorGrabWeapon.Foreground = Brushes.Green;
                    accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Green;
                    accountCreationWindow.PasswordTxtBox.BorderBrush = Brushes.Green;
                }
            }
            else
            {
                accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Red;
                accountCreationWindow.PasswordTxtBox.BorderBrush = Brushes.Red;
                accountCreationWindow.ErrorGrabWeapon.Content = "Please enter a value!";
                accountCreationWindow.ErrorGrabWeapon.Foreground = Brushes.Red;
                if (mysql.WeaponChosen == false)
                {
                    accountCreationWindow.ErrorGrabWeapon.Content = "Grab weapon to create account!";
                    accountCreationWindow.ErrorGrabWeapon.Foreground = Brushes.Red;

                }
            }
        }


        public void AccountGiveWeapon(string playerWeapon)
        {

            switch (playerWeapon)
            {
                case "Steel Sword":
                    viewModel.Player.EquippedWeapon = viewModel.steelSword;
                    break;
                case "Ruby Sword":
                    viewModel.Player.EquippedWeapon = viewModel.rubySword;

                    break;
                case "Excalibur":
                    viewModel.Player.EquippedWeapon = viewModel.excalibur;

                    break;
                case "Bow":
                    viewModel.Player.EquippedWeapon = viewModel.bow;

                    break;
                case "Staff":
                    viewModel.Player.EquippedWeapon = viewModel.staff;

                    break;
                default:
                    break;
            }


        }



        private void LoadAccountMethod2()
        {
            if (loadAccountWindow.UsernameTxtBox.Text != "" && loadAccountWindow.PasswordTxtBox.Text != "")
            {
                mysql.Username = loadAccountWindow.UsernameTxtBox.Text;
                mysql.Password = loadAccountWindow.PasswordTxtBox.Text;

                if (mysql.LoadAccount()) { loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Green; viewModel.PlayerUsername = mysql.Username; viewModel.Name = mysql.Username; viewModel.PlayerPassword = mysql.Password; loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Green; loadAccountWindow.UsernameTxtBox.Text = ""; loadAccountWindow.PasswordTxtBox.Text = "";
                    loadAccountWindow.ErrorGrabWeapon.Content = "Logged in successfully!";
                    loadAccountWindow.ErrorGrabWeapon.Foreground = Brushes.Green;
                    loadAccountWindow.PasswordTxtBox.BorderBrush = Brushes.Green;
                    loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Green;

                    viewModel.PlayerBaseAttack = mysql.BasicAttack;
                    //viewModel.= mysql.CurrentLocation.LocationMessage;
                    Menu.SaveButton.IsEnabled = true;
                    Menu.SaveLabel.Visibility = Visibility.Hidden;
                    viewModel.PlayerGold = mysql.Gold;
                    viewModel.PlayerHealth = mysql.Health;
                    viewModel.PlayerShield = mysql.Shield;
                    viewModel.PlayerShieldMax = mysql.ShieldMax;
                    if (mysql.Weapon != "Fists" && mysql.Weapon != null) {
                        this.AccountGiveWeapon(mysql.Weapon);
                        viewModel.GameMap.CurrentLocation.DefaultWeaponChosen = true;
                    }
                    else if(mysql.Weapon == "Fists" && mysql.PlayerX == 0 && mysql.PlayerY == 0)
                    {
                        viewModel.GameMap.CurrentLocation.DefaultWeaponChosen = false;
                    }

                        //
                    // Change the current location

                    viewModel.GameMap.CurrentLocationCoordinates.Row = mysql.PlayerY;
                    viewModel.GameMap.CurrentLocationCoordinates.Column= mysql.PlayerX; 
                    viewModel.PlayerXP = mysql.PlayerXP;
                    viewModel.PlayerLevel = mysql.Level;

                    switch (mysql.PlayerClass.ToLower())
                    {
                        case "mage":
                            viewModel.Player.ClassTypeProp = Player.ClassType.Mage;
                            viewModel.PlayerClassString = viewModel.Player.ClassToString;
                            viewModel.changePlayerClass("mage");

                            break;
                        case "warrior":
                            viewModel.Player.ClassTypeProp = Player.ClassType.Warrior;
                            viewModel.PlayerClassString = viewModel.Player.ClassToString;
                            viewModel.changePlayerClass("warrior");

                            break;
                        case "archer":
                            viewModel.Player.ClassTypeProp = Player.ClassType.Archer;
                            viewModel.PlayerClassString = viewModel.Player.ClassToString;
                            viewModel.changePlayerClass("archer"); 
                            break;
                        default:
                            break;
                    } 
                    Location.enableControls(view);
                    view.DialogueBox.Text = viewModel.CurrentLocation.LocationMessage;
                    view.TipsBox.Text = viewModel.CurrentLocation.LocationTip;

                    //viewModel.GameMap.MoveNorth();
                    //viewModel.LocationLootableItems = viewModel.GameMap.CurrentLocation.LootableItems;

                    /* if (_gameSessionViewModel.GameMap.NorthLocation().Accessible && !_gameSessionViewModel.AccessibleLocations.Contains(_gameSessionViewModel.GameMap.NorthLocation()))
                    {
                        _gameSessionViewModel.AccessibleLocations.Add(_gameSessionViewModel.GameMap.NorthLocation());
                    }*/


                    view.LocationName.Text = viewModel.GameMap.CurrentLocation.Name;
                    view.DialogueBox.Text = viewModel.GameMap.CurrentLocation.LocationMessage;
                    viewModel.ChanceOfFight();
                    viewModel.setLocationWarningMessage();

                    if (viewModel.GameMap.CurrentLocation.BossFightRoom)
                    {
                        if (!viewModel.bossesDefeated.Contains(viewModel.GameMap.CurrentLocation))
                        {
                            viewModel.bossRoomEnterUpdate();
                        }
                    }
                    viewModel.mapWindow.CurrentLocationDisplay.Text = viewModel.GameMap.CurrentLocation.Name;
                    viewModel.mapWindow.LocationDescriptionDisplay.Text = viewModel.GameMap.CurrentLocation.Description;
                    viewModel.updateAccessibleLocations();

                }
                else { loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Red;
                    loadAccountWindow.ErrorGrabWeapon.Content = "Invalid Credentials!";
                    loadAccountWindow.ErrorGrabWeapon.Foreground = Brushes.Red;

                }
            }
            else
            {
                loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Red;
                loadAccountWindow.PasswordTxtBox.BorderBrush = Brushes.Red;

                loadAccountWindow.ErrorGrabWeapon.Content = "Please enter a value!";
                loadAccountWindow.ErrorGrabWeapon.Foreground = Brushes.Red;

            }
        }
        #endregion

        #region GameMenuWindowCommands

        

        public ICommand ManageAccountCommand
        {
            get { return new DelegateCommand(ManageAccountMethod); }
        }
        public ICommand LeaderboardCommand
        {
            get { return new DelegateCommand(LeaderboardMethod); }
        }
        public ICommand QuitCommand
        {
            get { return new DelegateCommand(QuitMethod); }
        }
        public ICommand SaveGameCommand
        {
            get { return new DelegateCommand(SaveGameMethod); }
        }
        public ICommand LoadAccountCommand
        {
            get { return new DelegateCommand(LoadAccountMethod); }
        }
        public ICommand LoadAccountCommand2
        {
            get { return new DelegateCommand(LoadAccountMethod2); }
        }
        public ICommand CreateAccountWindowCommand
        {
            get { return new DelegateCommand(CreateAccountMethod); }
        }
        public ICommand DeleteAccountCommand
         {
            get { return new DelegateCommand(DeleteAccountMethod); }
         }
        public ICommand UpdateUsernameCommand
        {
            get { return new DelegateCommand(UpdateUsernameMethod); }
        }
        //
        // Delete Account Method
        //
        private void DeleteAccountMethod()
        {
            mysql.DeleteAccount(mysql.CurrentUsername);
        }
        private void LeaderboardMethod()
        {
            viewModel.leaderBoardWindow.Show();

            viewModel.MySQLMain.GetAllAccountsInfo();
        }

        //
        //Update Username Method
        //
        private void UpdateUsernameMethod()
        {
            if (manageAccountWindow.CurrentUsername.Text != "")
            {

                if (mysql.UpdateAccount(manageAccountWindow.CurrentUsername.Text))
                {
                    manageAccountWindow.CurrentUsername.BorderBrush = Brushes.DarkRed;
                    manageAccountWindow.CurrentUsername.Text = "";
                }
                else
                {
                    manageAccountWindow.CurrentUsername.BorderBrush = Brushes.Green;
                    manageAccountWindow.CurrentUsername.Text = "";
                    viewModel.Name = mysql.CurrentUsername;
                    viewModel.PlayerUsername = mysql.CurrentUsername;
                }

            }
        }



        //
        // Save Game Method
        //
        private void SaveGameMethod()
        {

            if (viewModel.PlayerBaseAttack != null)
            {
            mysql.BasicAttack = viewModel.PlayerBaseAttack;
            }
            if (viewModel.CurrentLocation.LocationMessage != null || viewModel.CurrentLocation.LocationMessage != "") {
                mysql.Dialogue = viewModel.CurrentLocation.LocationMessage;
            }
            if (viewModel.PlayerGold != null) {
                mysql.Gold = viewModel.PlayerGold;
            }
            if (viewModel.PlayerHealth != null)
            {
            mysql.Health = viewModel.PlayerHealth;
            }
            if (viewModel.PlayerShield != null) {
                mysql.Shield = viewModel.PlayerShield;
            }
            if (viewModel.PlayerShieldMax != null) {
                mysql.ShieldMax = viewModel.PlayerShieldMax;
            }
            if (viewModel.Player.EquippedWeapon == null) {
                mysql.Weapon = "Fists";
            }
            else
            {
                mysql.Weapon = viewModel.Player.EquippedWeapon.Name;
            }
            mysql.PlayerX = viewModel.GameMap.CurrentLocationCoordinates.Row;
            
            mysql.PlayerY = viewModel.GameMap.CurrentLocationCoordinates.Column;

            if (viewModel.PlayerXP != null)
            {
            mysql.PlayerXP = viewModel.PlayerXP;
            }
            if (viewModel.PlayerLevel != null)
            {
            mysql.Level = viewModel.PlayerLevel;
            }
            if (viewModel.Player.IsAlive != null)
            {
            mysql.IsAlive = true;
            }
            if (viewModel.PlayerClassString != null)
            {
            mysql.PlayerClass = viewModel.PlayerClassString;
            }


            mysql.SaveAccount();


        }
        //
        // Load Account Method
        //
        private void LoadAccountMethod()
        {
            loadAccountWindow.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            loadAccountWindow.Visibility = Visibility.Visible;
            
        }
        //
        // Quit Application
        // 
        private void QuitMethod()
        {
            Environment.Exit(0);
        }
        //
        // Create Account
        //
        private void CreateAccountMethod()
        {
             accountCreationWindow.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            accountCreationWindow.Show();
        }
        //
        // Manage Account
        //
        private void ManageAccountMethod()
        {
            manageAccountWindow.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            manageAccountWindow.Show();
        }
        #endregion

    }
}
