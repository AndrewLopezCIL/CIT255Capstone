﻿using MySql.Data;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataL
{
    public class MySQL
    {
        //
        // Constructor
        //
       public string connectionString = "SERVER=localhost;DATABASE=swendiverfinalproject;UID=root;PASSWORD=Snowboard1;";
        public MySQL()
        {
            MySqlConnection connection = new MySqlConnection(connectionString);

            MySqlCommand cmd = new MySqlCommand("INSERT INTO `Accounts`(`playerUsername`, `playerPassword`) VALUES('Default', 'password')",connection);
            
        }





    }
}
