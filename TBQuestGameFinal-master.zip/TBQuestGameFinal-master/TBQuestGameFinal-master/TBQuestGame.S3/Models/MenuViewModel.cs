﻿using DataLP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using TBQuestGame.PresentationLayer;

namespace TBQuestGame.Models
{
    public class MenuViewModel
    {
        public CreateAccount accountCreationWindow;
        public ManageAccount manageAccountWindow;
        public LoadAccount loadAccountWindow;
        GameMenuDisplay Menu;
        GameSessionViewModel viewModel;
        GameSessionView view;
        MySQL mysql;
        //public DataLP.MySQL mysql = new DataLP.MySQL();
        public MenuViewModel(GameSessionViewModel vm, MySQL mysql, GameMenuDisplay Menu, GameSessionView view)
        { 
            Menu.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;

            accountCreationWindow = new CreateAccount(vm, mysql);
            manageAccountWindow = new ManageAccount();
            this.Menu = Menu;
            manageAccountWindow.DataContext = this;
            this.loadAccountWindow = new LoadAccount(vm,mysql);
            loadAccountWindow.DataContext = this;
            this.mysql = mysql;
            viewModel = vm;
            accountCreationWindow.DataContext = this;
            this.view = view;
        }

        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            Menu.Visibility = Visibility.Hidden;
        }


        #region CreateAccountWindowCommands
        public ICommand CreateAccountCommand
        {
            get { return new DelegateCommand(CreateAccountMethod2); }
        }

       


        private void CreateAccountMethod2()
        {
            if (accountCreationWindow.UsernameTxtBox.Text != "" && accountCreationWindow.PasswordTxtBox.Text != ""&& mysql.WeaponChosen == true)
            {
                mysql.Username = accountCreationWindow.UsernameTxtBox.Text;
                mysql.Password = accountCreationWindow.PasswordTxtBox.Text;

                if (mysql.CreateAccount()) { accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Red; }
                else {
                   
                   SaveGameMethod();
                    viewModel.PlayerUsername = mysql.Username; viewModel.Name = mysql.Username; viewModel.PlayerPassword = mysql.Password; accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Green; accountCreationWindow.UsernameTxtBox.Text = ""; accountCreationWindow.PasswordTxtBox.Text = ""; accountCreationWindow.Visibility = Visibility.Hidden;
                    
                }
            }
            else
            {
                accountCreationWindow.UsernameTxtBox.BorderBrush = Brushes.Red;
                accountCreationWindow.PasswordTxtBox.BorderBrush = Brushes.Red;
            }
        }


        private void LoadAccountMethod2()
        {
            if (loadAccountWindow.UsernameTxtBox.Text != "" && loadAccountWindow.PasswordTxtBox.Text != "")
            {
                mysql.Username = loadAccountWindow.UsernameTxtBox.Text;
                mysql.Password = loadAccountWindow.PasswordTxtBox.Text;

                if (mysql.LoadAccount()) { loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Green; viewModel.PlayerUsername = mysql.Username; viewModel.Name = mysql.Username; viewModel.PlayerPassword = mysql.Password; loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Green; loadAccountWindow.UsernameTxtBox.Text = ""; loadAccountWindow.PasswordTxtBox.Text = ""; loadAccountWindow.Visibility = Visibility.Hidden;

                    viewModel.PlayerBaseAttack = mysql.BasicAttack;
                    //viewModel.= mysql.CurrentLocation.LocationMessage;
                    viewModel.PlayerGold = mysql.Gold;
                    viewModel.PlayerHealth = mysql.Health;
                    viewModel.PlayerShield = mysql.Shield;
                    viewModel.PlayerShieldMax = mysql.ShieldMax;
                    if (mysql.Weapon != "Fists") {
                        view.AccountGiveWeapon(mysql.Weapon);
                        viewModel.GameMap.CurrentLocation.DefaultWeaponChosen = true;
                    }
                    else if(mysql.Weapon == "Fists" && mysql.PlayerX == 0 && mysql.PlayerY == 0)
                    {
                        viewModel.GameMap.CurrentLocation.DefaultWeaponChosen = false;
                    }

                        //
                    // Change the current location

                    viewModel.GameMap.CurrentLocationCoordinates.Row = mysql.PlayerY;
                    viewModel.GameMap.CurrentLocationCoordinates.Column= mysql.PlayerX; 
                    viewModel.PlayerXP = mysql.PlayerXP;
                    viewModel.PlayerLevel = mysql.Level;

                    switch (mysql.PlayerClass.ToLower())
                    {
                        case "mage":
                            viewModel.Player.ClassTypeProp = Player.ClassType.Mage;
                            viewModel.PlayerClassString = viewModel.Player.ClassToString;
                            view.changePlayerClass("mage");

                            break;
                        case "warrior":
                            viewModel.Player.ClassTypeProp = Player.ClassType.Warrior;
                            viewModel.PlayerClassString = viewModel.Player.ClassToString;
                            view.changePlayerClass("warrior");

                            break;
                        case "archer":
                            viewModel.Player.ClassTypeProp = Player.ClassType.Archer;
                            viewModel.PlayerClassString = viewModel.Player.ClassToString;
                            view.changePlayerClass("archer"); 
                            break;
                        default:
                            break;
                    } 
                    Location.enableControls(view);
                    view.DialogueBox.Text = viewModel.CurrentLocation.LocationMessage;
                    view.TipsBox.Text = viewModel.CurrentLocation.LocationTip;

                    viewModel.GameMap.MoveNorth();
                    viewModel.LocationLootableItems = viewModel.GameMap.CurrentLocation.LootableItems;

                    /* if (_gameSessionViewModel.GameMap.NorthLocation().Accessible && !_gameSessionViewModel.AccessibleLocations.Contains(_gameSessionViewModel.GameMap.NorthLocation()))
                    {
                        _gameSessionViewModel.AccessibleLocations.Add(_gameSessionViewModel.GameMap.NorthLocation());
                    }*/


                    view.LocationName.Text = viewModel.GameMap.CurrentLocation.Name;
                    view.DialogueBox.Text = viewModel.GameMap.CurrentLocation.LocationMessage;
                    view.ChanceOfFight();
                    view.setLocationWarningMessage(viewModel, view);

                    if (viewModel.GameMap.CurrentLocation.BossFightRoom)
                    {
                        if (!viewModel.bossesDefeated.Contains(viewModel.GameMap.CurrentLocation))
                        {
                            view.bossRoomEnterUpdate();
                        }
                    }
                    view.mapWindow.CurrentLocationDisplay.Text = viewModel.GameMap.CurrentLocation.Name;
                    view.mapWindow.LocationDescriptionDisplay.Text = viewModel.GameMap.CurrentLocation.Description;
                    view.updateAccessibleLocations();

                }
                else { loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Red; }
            }
            else
            {
                loadAccountWindow.UsernameTxtBox.BorderBrush = Brushes.Red;
                loadAccountWindow.PasswordTxtBox.BorderBrush = Brushes.Red;
            }
        }
        #endregion

        #region GameMenuWindowCommands

        

        public ICommand ManageAccountCommand
        {
            get { return new DelegateCommand(ManageAccountMethod); }
        }
        public ICommand QuitCommand
        {
            get { return new DelegateCommand(QuitMethod); }
        }
        public ICommand SaveGameCommand
        {
            get { return new DelegateCommand(SaveGameMethod); }
        }
        public ICommand LoadAccountCommand
        {
            get { return new DelegateCommand(LoadAccountMethod); }
        }
        public ICommand LoadAccountCommand2
        {
            get { return new DelegateCommand(LoadAccountMethod2); }
        }
        public ICommand CreateAccountWindowCommand
        {
            get { return new DelegateCommand(CreateAccountMethod); }
        }
        public ICommand DeleteAccountCommand
         {
            get { return new DelegateCommand(DeleteAccountMethod); }
         }
        public ICommand UpdateUsernameCommand
        {
            get { return new DelegateCommand(UpdateUsernameMethod); }
        }
        //
        // Delete Account Method
        //
        private void DeleteAccountMethod()
        {
            mysql.DeleteAccount(mysql.CurrentUsername);
        }


        //
        //Update Username Method
        //
        private void UpdateUsernameMethod()
        {
            if (manageAccountWindow.CurrentUsername.Text != "")
            {

                if (mysql.UpdateAccount(manageAccountWindow.CurrentUsername.Text))
                {
                    manageAccountWindow.CurrentUsername.BorderBrush = Brushes.DarkRed;
                    manageAccountWindow.CurrentUsername.Text = "";
                }
                else
                {
                    manageAccountWindow.CurrentUsername.BorderBrush = Brushes.Green;
                    manageAccountWindow.CurrentUsername.Text = "";
                    viewModel.Name = mysql.CurrentUsername;
                    viewModel.PlayerUsername = mysql.CurrentUsername;
                }

            }
        }



        //
        // Save Game Method
        //
        private void SaveGameMethod()
        {

            if (viewModel.PlayerBaseAttack != null)
            {
            mysql.BasicAttack = viewModel.PlayerBaseAttack;
            }
            if (viewModel.CurrentLocation.LocationMessage != null || viewModel.CurrentLocation.LocationMessage != "") {
                mysql.Dialogue = viewModel.CurrentLocation.LocationMessage;
            }
            if (viewModel.PlayerGold != null) {
                mysql.Gold = viewModel.PlayerGold;
            }
            if (viewModel.PlayerHealth != null)
            {
            mysql.Health = viewModel.PlayerHealth;
            }
            if (viewModel.PlayerShield != null) {
                mysql.Shield = viewModel.PlayerShield;
            }
            if (viewModel.PlayerShieldMax != null) {
                mysql.ShieldMax = viewModel.PlayerShieldMax;
            }
            if (viewModel.Player.EquippedWeapon == null) {
                mysql.Weapon = "Fists";
            }
            else
            {
                mysql.Weapon = viewModel.Player.EquippedWeapon.Name;
            }
            mysql.PlayerX = viewModel.GameMap.CurrentLocationCoordinates.Row;
            
            mysql.PlayerY = viewModel.GameMap.CurrentLocationCoordinates.Column;

            if (viewModel.PlayerXP != null)
            {
            mysql.PlayerXP = viewModel.PlayerXP;
            }
            if (viewModel.PlayerLevel != null)
            {
            mysql.Level = viewModel.PlayerLevel;
            }
            if (viewModel.Player.IsAlive != null)
            {
            mysql.IsAlive = true;
            }
            if (viewModel.PlayerClassString != null)
            {
            mysql.PlayerClass = viewModel.PlayerClassString;
            }


            mysql.SaveAccount();


        }
        //
        // Load Account Method
        //
        private void LoadAccountMethod()
        {
            loadAccountWindow.Show();
        }
        //
        // Quit Application
        // 
        private void QuitMethod()
        {
            Environment.Exit(0);
        }
        //
        // Create Account
        //
        private void CreateAccountMethod()
        {
            accountCreationWindow.Show();
        }
        //
        // Manage Account
        //
        private void ManageAccountMethod()
        {
            manageAccountWindow.Show();
        }
        #endregion

    }
}
